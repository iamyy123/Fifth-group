import React from 'react';
import SysPage from './SysPage';
import MyTitle from './SysPage/MyTitle';
import SysPage2 from './SysPage2';

const App = () => {

  return (
    <>
    <SysPage2></SysPage2>
    </>
  );
}

export default App;


