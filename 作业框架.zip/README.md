# ForSchoolReact

## 先决条件   
1. 安装nodejs
2. 安装pnpm ：  npm install -g pnpm  


## 启动和运行
pnpm  install  
pnpm  run dev  


## github基础操作  == 正式上课时再使用
查看状态： git status  
添加当前代码到笔记本电脑的本地仓库：  git add .  
提交一个新版本: git commit -a -m 新版本号比如230113  
提交本地版本到远程仓库： git push  
更新本地的代码： git pull  
